-TurboDB Studio 4 Praxishandbuch Lehrbeispiel ADRESSEN (c) 2012 Robert W.B. Linn
Ein TurboDB Studio Open Source Projekt.
Freeware unter Einhaltung der GPL (siehe lizenz.rtf).

Autor: R.W.B. Linn, Pinneberg, Germany
Internet: www.rwblinn.de | E-Mail: robert@rwblinn.de

-Inhalt
* Kurzbeschreibung
* Installation
* Hinweise
* Historie

-Kurzbeschreibung
Ein TurboDB Studio 4 Lehrbeispiel ADRESSEN.
ADRESSEN ist keine fertige Anwendung.
Es werden verschiedene TurboDB Studio 4 Funktionen gezeigt. 

-Installation
Die Datei ts4phbadressen.zip entpacken, dabei die Verzeichnisstruktur beibehalten.
TurboDB Studio starten und ts4phbadressen.tdb laden.

-Hinweise
Vielen Dank f�r Ihr Interesse.
Wenn Sie Verbesserungen, Ideen, Kommentare etc. haben, 
bitte nur per E-Mail an Autor.

-Historie
�bersicht der �nderungen/Verbesserungen
(+) = Neu, (*) = Verbessert, (-) = Entfernt
20120212
(+) Erste Version ver�ffentlicht
