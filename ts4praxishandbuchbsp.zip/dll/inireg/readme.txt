-DLL IniReg (c) 2012 Robert W.B. Linn, Pinneberg, Germany
Freeware unter Einhaltung der GNU General Public License (www.gnu.org/licenses).

Autor: R.W.B. Linn, Pinneberg, Germany
Internet: www.rwblinn.de | E-Mail: robert@rwblinn.de

Downloads
* <!file://inireg.zip|inireg>

-[Inhalt]
+ [Beschreibung]
+ [Installation]
+ [TurboPL Deklaration]
+ [Hinweise]
+ [Historie]

-[Beschreibung]
DLL IniReg bietet Funktionen um Werte aus der Windows Registrierung (Registry)
oder aus Ini-Dateien zu lesen und/oder schreiben

!!!Wichtiger Hinweis!!!
Zu bemerken sei, dass �nderungen an Ini-Dateien und der Windows Registrierung 
mit aller gr��ten Vorsicht vorgenommen werden, sollten. 
Es ist dringend zu empfehlen, erst eine Sicherung zu erstellen, bevor 
�nderungen vorgenommen werden.
Der Autor �bernimmt keine Haftung f�r die Ausf�hrung der Funktionen.
!!!

-[Installation]
Kopiere die Datei inireg.zip in ein beliebiges Verzeichnis 
Unzip die Datei inireg.zip mittels z.B. pkunzip inireg.zip
Kopiere die inireg.dll in das jeweilige TurboDB Studio Anwendungsverzeichnis.

-[TurboPL Deklaration]
..
.. INI-Dateien
DLLProc IniGetValue(sIniDatei: String as LPStr; sIniSektion: String as LPStr; sIniSchluessel: String as LPStr; sIniWertDefault: String as LPStr; VAR sIniWert: String as LPStr; maxlen: Integer as I4) library "inireg.dll";

DLLProc IniSetValue(sIniDatei: String as LPStr; sIniSektion: String as LPStr; sIniSchluessel: String as LPStr; sIniWert: string as LPStr): Integer library "inireg.dll";

DLLProc IniDelValue(sIniDatei:	String as LPStr; sIniSektion: String as LPStr; pStringName: String as LPStr): Integer library "inireg.dll";

DLLProc IniDelSection(pFile: String as LPStr; pSection: String as LPStr) : Integer library "inireg.dll";

.. REGISTRY
DLLProc RegGetValue(sRootKey : String as LPStr; sKey : String as LPStr; sValue : String as LPStr; Var sResult : String as LPStr; maxlen : Integer) library "inireg.dll";

DLLProc RegSetValue(sRootKey : String as LPStr; sKey : String as LPStr; sVar : String as LPStr; sValue : String as LPStr): Integer library "inireg.dll";
..

-[Hinweise]
Neue Versionen und Updates um Internet unter www.rwblinn.de
Hinweise, Ideen und Tipps sind nat�rlich willkommen.

-[Historie]
(+) = neu; (*) = ge�ndert; (-) = entfernt
01.12.2012
(+) Erste Version
